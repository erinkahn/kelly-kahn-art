<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'kkart');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'D&%geh`@`qdqxpo}}UyPHBXUR/{ O~sazuh](IN{A5(=#49/b4Aue*hyJ2[:+Z2L');
define('SECURE_AUTH_KEY',  'sXW1tg!W Vgb_V7=`ahOI1jRKJ2fMOFRH0F;J7ajj3.R*1z`Tn%[BwO9H,ZeX|X8');
define('LOGGED_IN_KEY',    '%dB;~3b[04_w_U7Ox7W^6%_k`Of*6f*[A5yH~,CzxpUb2Iu{M _ -UGp|Y~aG2dB');
define('NONCE_KEY',        'k_Z#/[A$d8*WJ%k#F+u)~=bO`Q:[%YLmmF?)74?P_I2X&.5 >-sP79b3ObK`N?a9');
define('AUTH_SALT',        '.]3@pJk3/f^qEjP<Q?!:t_{fgviy#bx`Ao9=eRZ)[WzAk!k=-!J. 8lOB|E_J>zQ');
define('SECURE_AUTH_SALT', 'h/.Ye~fRS)FcX6VFscWBsV99X~3!wBBu^P{{:,&,5!gPZ9L6fZ52a6EAT gl~vv>');
define('LOGGED_IN_SALT',   '9.mnexx5>[mK/,R_P8G6xfb=M/h,PB5AN7DL8S>[rUl_#ZzQ_ax/d}[DqDGa}cZ:');
define('NONCE_SALT',       '+&={GVPy1fFk~=wKF?Zgpk^]>f17]Hq,._OvHZ3pQkP^|c.x&m19]lI *s gr{k}');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wprx_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
